import axios from 'axios';

const API_URL = "http://localhost:8000";

// Sign Up User
export const signUpUser = async (fullName, email, password) => {
  const response = await axios.post(`${API_URL}/signup`, {
    fullName,
    email,
    password
  });
  return response.data;
};

// Sign In User
export const signInUser = async (email, password) => {
  const response = await axios.post(`${API_URL}/signin`, { email, password });
  return response.data;
};

// Create New Chat
export const createChat = async (user_id, title, model_id = 1) => {
  const response = await axios.post(`${API_URL}/newchat`, { user_id, title, model_id });
  return response.data;
};

// Submit Query
export const submitQuery = async (chat_id, user_message) => {
  const response = await axios.post(`${API_URL}/query`, { chat_id, user_message });
  return response.data;
};

// Fetch user chats
export const fetchUserChats = async (user_id) => {
  const response = await axios.get(`${API_URL}/chats`, { params: { user_id } });
  return response.data;
};

// Fetch messages for a chat
export const fetchChatMessages = async (chat_id) => {
  const response = await axios.get(`${API_URL}/messages`, { params: { chat_id } });
  return response.data;
};

// Rename chat
export const renameChatAPI = async (chatId, newTitle) => {
  const response = await axios.put(`${API_URL}/renameChat`, { chat_id: chatId, new_title: newTitle });
  return response.data;
};

// Delete chat (and its messages)
export const deleteChatAPI = async (chatId) => {
  const response = await axios.delete(`${API_URL}/deleteChat/${chatId}`);
  return response.data;
};

// Suggest new chat's name to rename
export const suggestTitle = async (chat_id, query) => {
  try {
    const response = await axios.post(`${API_URL}/suggestTitle`, { chat_id, query });
    return response.data;
  } catch (error) {
    console.error('Error fetching suggested title:', error);
    return { title: 'Untitled Chat' };
  }
};
