const Support = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Support</h2>
      <p>Contact our support team or view your support tickets here.</p>
    </div>
  );
};

export default Support;
