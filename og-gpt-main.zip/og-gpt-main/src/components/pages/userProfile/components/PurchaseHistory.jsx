import React from "react";

const PurchaseHistory = () => {
  const purchases = [
    { id: 1, service: "Advanced Drilling Insights", date: "2024-11-10", amount: "$120" },
    { id: 2, service: "Operational Safety Analysis", date: "2024-10-05", amount: "$80" },
  ];

  return (
    <div className="bg-gray-100 p-6 rounded-lg">
      <h2 className="text-lg font-bold text-[#22195b] mb-4">
        Purchase History
      </h2>
      <ul className="space-y-3">
        {purchases.map((purchase) => (
          <li
            key={purchase.id}
            className="flex justify-between items-center p-4 bg-white rounded-md shadow-md"
          >
            <div>
              <p className="font-bold">{purchase.service}</p>
              <p className="text-sm text-gray-500">{purchase.date}</p>
            </div>
            <p className="text-[#22195b] font-medium">{purchase.amount}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PurchaseHistory;
