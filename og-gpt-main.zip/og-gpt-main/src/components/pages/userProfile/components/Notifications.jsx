const Notifications = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Notifications</h2>
      <p>No new notifications at the moment.</p>
    </div>
  );
};

export default Notifications;
