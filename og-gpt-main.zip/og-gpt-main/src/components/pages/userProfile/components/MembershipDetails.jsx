import React, { useState } from "react";

const MembershipDetails = () => {
  const [membership, setMembership] = useState({
    status: "Active",
    plan: "Premium",
    expiryDate: "2025-12-31",
  });

  const handleRenew = () => {
    // Handle membership renewal logic
    alert("Membership Renew Feature Coming Soon!");
  };

  return (
    <div className="bg-gray-100 p-6 rounded-lg mb-4">
      <h2 className="text-lg font-bold text-[#22195b] mb-4">
        Membership Details
      </h2>
      <div className="space-y-2">
        <p><strong>Status:</strong> {membership.status}</p>
        <p><strong>Plan:</strong> {membership.plan}</p>
        <p><strong>Expiry Date:</strong> {membership.expiryDate}</p>
      </div>
      <button
        onClick={handleRenew}
        className="mt-4 px-4 py-2 bg-[#22195b] text-white rounded-md hover:bg-[#352c84] transition-all"
      >
        Renew Membership
      </button>
    </div>
  );
};

export default MembershipDetails;
