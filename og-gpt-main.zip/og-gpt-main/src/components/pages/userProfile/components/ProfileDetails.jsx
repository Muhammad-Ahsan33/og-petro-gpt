import React, { useState } from "react";

const ProfileDetails = () => {
  const [user, setUser] = useState({
    name: "John Doe",
    email: "john@example.com",
    phone: "+1234567890",
  });

  const handleEdit = () => {
    // Handle edit logic here
    alert("Edit Profile Feature Coming Soon!");
  };

  return (
    <div className="bg-gray-100 p-6 rounded-lg mb-4">
      <h2 className="text-lg font-bold text-[#22195b] mb-4">
        Profile Details
      </h2>
      <div className="space-y-2">
        <p><strong>Name:</strong> {user.name}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Phone:</strong> {user.phone}</p>
      </div>
      <button
        onClick={handleEdit}
        className="mt-4 px-4 py-2 bg-[#22195b] text-white rounded-md hover:bg-[#352c84] transition-all"
      >
        Edit Profile
      </button>
    </div>
  );
};

export default ProfileDetails;
