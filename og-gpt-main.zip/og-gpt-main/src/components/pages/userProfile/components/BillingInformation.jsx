const BillingInformation = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Billing Information</h2>
      <p>Manage your payment methods and view invoices here.</p>
    </div>
  );
};

export default BillingInformation;
