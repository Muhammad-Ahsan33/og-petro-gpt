const ActivityLog = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Activity Log</h2>
      <p>Track your recent activities and updates here.</p>
    </div>
  );
};

export default ActivityLog;
