import React from "react";

const Settings = () => {
  const handlePasswordChange = () => {
    // Handle password change logic here
    alert("Password Change Feature Coming Soon!");
  };

  return (
    <div className="bg-gray-100 p-6 rounded-lg">
      <h2 className="text-lg font-bold text-[#22195b] mb-4">Account Settings</h2>
      <button
        onClick={handlePasswordChange}
        className="px-4 py-2 bg-[#22195b] text-white rounded-md hover:bg-[#352c84] transition-all"
      >
        Change Password
      </button>
    </div>
  );
};

export default Settings;
