import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Assuming you are using React Router
import { useAuth } from "../../../context/AuthContext"; // Import the useAuth hook
import ProfileDetails from "./components/ProfileDetails";
import MembershipDetails from "./components/MembershipDetails";
import PurchaseHistory from "./components/PurchaseHistory";
import Settings from "./components/Settings";
import Notifications from "./components/Notifications";
import BillingInformation from "./components/BillingInformation";
import ActivityLog from "./components/ActivityLog";
import Support from "./components/Support";
import {
  FaBars,
  FaTimes,
  FaHome,
  FaComments,
  FaUser,
  FaCreditCard,
  FaHistory,
  FaCogs,
  FaBell,
  FaBook,
  FaLifeRing,
} from "react-icons/fa";

const ProfilePage = () => {
  const [activeTab, setActiveTab] = useState("profile");
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { logout } = useAuth(); // Access the logout function from AuthContext

  const handleTabClick = (tab) => {
    setActiveTab(tab);
    setIsMenuOpen(false); // Close menu on mobile when a tab is clicked
  };

  const handleLogout = () => {
    logout(); // Update the authentication state
    navigate("/auth"); // Redirect to the home or login page
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "profile":
        return <ProfileDetails />;
      case "membership":
        return <MembershipDetails />;
      case "purchases":
        return <PurchaseHistory />;
      case "settings":
        return <Settings />;
      case "notifications":
        return <Notifications />;
      case "billing":
        return <BillingInformation />;
      case "activity":
        return <ActivityLog />;
      case "support":
        return <Support />;
      default:
        return <ProfileDetails />;
    }
  };

  const tabs = [
    { tab: "profile", label: "Profile Details", icon: <FaUser /> },
    { tab: "membership", label: "Membership Details", icon: <FaCreditCard /> },
    { tab: "purchases", label: "Purchase History", icon: <FaHistory /> },
    { tab: "settings", label: "Settings", icon: <FaCogs /> },
    { tab: "notifications", label: "Notifications", icon: <FaBell /> },
    { tab: "billing", label: "Billing Information", icon: <FaBook /> },
    { tab: "activity", label: "Activity Log", icon: <FaHistory /> },
    { tab: "support", label: "Support", icon: <FaLifeRing /> },
  ];

  return (
    <div className="min-h-screen w-full flex items-start justify-start bg-softblack text-softwhite">
      <div className="w-full h-full bg-softwhite text-softblack rounded-lg shadow-lg flex flex-col md:flex-row">
        {/* Mobile Menu Icon */}
        <button
          className="md:hidden bg-themepurple text-softwhite p-4"
          onClick={() => setIsMenuOpen((prev) => !prev)}
        >
          {isMenuOpen ? <FaTimes size={20} /> : <FaBars size={20} />}
        </button>

        {/* Left Tab Menu (Aligned to the left) */}
        <div
          className={`absolute md:static top-0 left-0 h-full bg-softwhite shadow-lg md:w-1/5 border-r border-gray-200 z-20 transform ${
            isMenuOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
          } transition-transform duration-300`}
        >
          <ul
            className={`space-y-4 p-8 bg-white md:p-4 ${
              isMenuOpen ? "" : "flex flex-col space-y-2"
            }`}
          >
            <button
              className="md:hidden bg-red-500 text-white p-1 rounded-md hover:bg-themepurple/80"
              onClick={() => setIsMenuOpen((prev) => !prev)}
            >
              {isMenuOpen ? <FaTimes size={20} /> : " "}
            </button>
            {tabs.map(({ tab, label, icon }) => (
              <li key={tab}>
                <button
                  className={`w-full flex justify-start items-center text-left p-2 rounded-md font-medium ${
                    activeTab === tab
                      ? "bg-themepurple text-white"
                      : "text-softblack hover:bg-gray-100"
                  }`}
                  onClick={() => handleTabClick(tab)}
                >
                  <span className="mr-2">{icon}</span> {/* Icon first */}
                   <span>{label}</span>
                  {/* Label shows only if menu is open */}
                </button>
              </li>
            ))}
            {/* Logout Button */}
            <li>
              <button
                className="w-full flex items-center text-left p-2 rounded-md text-white font-medium bg-red-500 text-softwhite hover:bg-red-600"
                onClick={handleLogout}
              >
                <span className="mr-2">
                  <FaTimes />
                </span>
                {isMenuOpen || <span>Logout</span>}
              </button>
            </li>
          </ul>
        </div>

        {/* Right Content */}
        <div className="w-full md:w-4/5 p-6">
          {/* Navigation Buttons at the Top */}
          <div className="flex justify-end mb-4 space-x-4">
            <button
              className="p-2 bg-themepurple text-white rounded-full hover:bg-[#352c84] transition-all duration-300"
              onClick={() => navigate("/")}
            >
              <FaHome size={20} />
            </button>
            <button
              className="p-2 bg-gray-500 text-white rounded-full hover:bg-gray-600 transition-all duration-300"
              onClick={() => navigate("/chat")}
            >
              <FaComments size={20} />
            </button>
          </div>

          <h1 className="text-2xl font-bold mb-6 text-themepurple">
            My Profile
          </h1>
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
