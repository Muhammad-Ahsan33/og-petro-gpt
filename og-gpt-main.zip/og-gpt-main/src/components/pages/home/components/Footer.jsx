import { Facebook, Twitter, Linkedin, Instagram } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-[#262626] text-white py-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Top Section (Contact & Social Links) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-8">
          {/* Contact Info */}
          <div>
            <h3 className="text-2xl font-semibold mb-4">Contact Info</h3>
            <p className="mb-4">198 West 21st Street, Suite 721 New York, NY 10016</p>
            <p className="mb-4">📞 +1235 2355 98</p>
            <p className="mb-4">📧 info@ogfleet.com</p>
          </div>

          {/* Social Media Links */}
          <div>
            <h3 className="text-2xl font-semibold mb-4">Follow Us</h3>
            <div className="flex gap-6">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-3xl hover:text-indigo-300">
                <Facebook />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-3xl hover:text-indigo-300">
                <Twitter />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-3xl hover:text-indigo-300">
                <Linkedin />
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-3xl hover:text-indigo-300">
                <Instagram />
              </a>
            </div>
          </div>

          {/* Newsletter Signup */}
          <div>
            <h3 className="text-2xl font-semibold mb-4">Subscribe to our Newsletter</h3>
            <form className="flex flex-col">
              <input
                type="email"
                placeholder="Enter your email"
                className="p-3 mb-4 rounded-lg bg-indigo-800 text-white"
              />
              <button type="submit" className="py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition duration-200">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        {/* Bottom Section (Quick Links & Copyright) */}
        <div className="flex justify-between items-center border-t border-gray-400 pt-6 mt-6">
          {/* Quick Links */}
          <div className="flex gap-8">
            <a href="#home" className="hover:text-indigo-300">Home</a>
            <a href="#about" className="hover:text-indigo-300">About</a>
            <a href="#services" className="hover:text-indigo-300">Services</a>
            <a href="#contact" className="hover:text-indigo-300">Contact</a>
          </div>

          {/* Copyright */}
          <p className="text-sm text-gray-400">
            &copy; 2024 OGFLEET. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
