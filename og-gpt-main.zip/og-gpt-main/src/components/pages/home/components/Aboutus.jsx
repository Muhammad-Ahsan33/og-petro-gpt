import React, { useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import { motion } from "framer-motion";

const Aboutus = () => {
  const navigate = useNavigate();
  useEffect(() => {
    const aboutSection = document.querySelector(".about");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.2 }
    );

    observer.observe(aboutSection);
    return () => observer.unobserve(aboutSection);
  }, []);

  const navigateToauth = () => {
    navigate('/auth');
  };

  return (
    <motion.section
      id="about"
      className="about bg-gradient-to-r to-[#f8f0fb] from-[#f9fae4] bg-gray-50 py-16 lg:py-24 translate-y-12 transition-all duration-1000"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1 }}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
        {/* Section Heading */}
        <motion.h2
          className="text-[18px] sm:text-[20px] md:text-[20px] font-bold text-themepurple mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 1 }}
        >
         ABOUT OGFLEET
        </motion.h2>

        {/* Main Content: Flex Layout */}
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Left: Text Content */}
          <div className="w-full lg:w-1/2 flex flex-col justify-center space-y-6">
            <motion.p
              className="text-sm sm:text-lg md:text-[16px] lg:text-[16px] text-gray-600 leading-relaxed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 1 }}
            >
              Powered by GPT technology, OGFLEET combines the power of
              artificial intelligence with the expertise required in petroleum
              engineering. It offers a virtual assistant that provides answers
              to complex queries, makes real-time decisions, and helps automate
              mundane tasks, freeing up valuable time for engineers to focus on
              more critical aspects of their work.
            </motion.p>

            {/* Call to Action */}
            <motion.div
              className="text-gray-800"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7, duration: 1 }}
            >
              <h3 className="text-lg sm:text-xl lg:text-lg font-semibold mb-4 text-themepurple">
                Join Us Today!
              </h3>
              <p className="text-sm sm:text-base lg:text-lg leading-relaxed mb-6">
                Ready to optimize your drilling operations with AI? Sign up now
                and experience the future of petroleum engineering with OGFLEET.
              </p>
              <button onClick={navigateToauth} className="bg-softBlack text-white py-2 px-6 rounded-lg hover:bg-themepurple transition-all">
                Sign Up
              </button>
            </motion.div>
          </div>

          {/* Right: Image */}
          <div className="w-full lg:w-1/2 flex justify-center">
            <motion.div
              className="w-full h-full"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ delay: 1, duration: 1 }}
            >
              <img
                src="/Aboutus.png"
                alt="OGFLEET Visualization"
                className="w-full max-w-md sm:max-w-lg md:max-w-full h-auto object-contain rounded-lg "
              />
            </motion.div>
          </div>
        </div>
      </div>
    </motion.section>
  );
};

export default Aboutus;
