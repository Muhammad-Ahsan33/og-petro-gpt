import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import { useAuth } from "../../../../context/AuthContext"; // Import useAuth for authentication check
import homeImage from "../../../../assets/home.webp";

const Hero = () => {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: false, amount: 0.5 }); // `once: false` allows re-triggering
  const navigate = useNavigate(); // Initialize navigation
  const { isAuthenticated } = useAuth(); // Get authentication status

  const handleGetStartedClick = () => {
    if (isAuthenticated) {
      navigate("/chat"); // Navigate to chat if authenticated
    } else {
      navigate("/auth"); // Navigate to auth if not authenticated
    }
  };

  return (
    <motion.section
      id="home"
      ref={sectionRef}
      className="w-full h-screen bg-gradient-to-r from-[#f8f0fb] to-[#f9fae4] text-[#20182e] flex justify-center items-center relative px-4"
      initial={{ opacity: 1, y: 30 }}
      transition={{ duration: 0.3, ease: "linear" }} // Faster and smoother animation
    >
      <div className="container mx-auto w-full flex flex-col md:flex-row justify-center items-center gap-10 px-6">
        {/* Image Section */}
        <motion.div
          className="flex-1 flex justify-center md:max-w-[45%]"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
          transition={{ duration: 0.3, ease: "linear" }}
        >
          <img
            src={homeImage}
            alt="Home"
            className="w-full max-w-xs sm:max-w-md lg:max-w-full h-auto"
          />
        </motion.div>

        {/* Text Section */}
        <motion.div
          className="flex-1 md:max-w-[45%] text-center md:text-left lg:pl-20 flex flex-col justify-center items-center md:items-start"
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
          transition={{ duration: 0.3, ease: "linear" }} // Matches the section's animation
          style={{ fontFamily: "Helvetica, Arial, sans-serif" }}
        >
          <h1 className="text-2xl sm:text-3xl lg:text-5xl font-bold leading-snug mb-5">
            Advanced software
            <br /> made simple
          </h1>
          <p className="text-sm sm:text-lg lg:text-[18px] font-medium mb-6">
            Your trusted Petroleum Chatbot for Drilling Operations
          </p>
          <button
            onClick={handleGetStartedClick} // Updated click handler
            className="px-6 py-2 border rounded-lg text-base bg-[#6832C5] sm:text-md text-white lg:text-md font-medium transition-all duration-300 hover:bg-[#20182e]"
          >
            Get Started
          </button>
        </motion.div>
      </div>
    </motion.section>
  );
};

export default Hero;
