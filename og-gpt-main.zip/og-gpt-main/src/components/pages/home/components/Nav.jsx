import React, { useState, useEffect, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useAuth } from "../../../../context/AuthContext";
import { useNavigate } from "react-router-dom"; // Import useNavigate

const Nav = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuActive, setIsMenuActive] = useState(false);
  const { login, logout, isLoggedIn } = useAuth(); // Using isLoggedIn instead of isAuthenticated
  const menuRef = useRef(null);
  const hamburgerRef = useRef(null);
  const navigate = useNavigate(); // Initialize useNavigate
  const [isDropdownOpen, setIsDropdownOpen] = useState(false); // Dropdown state

  const handleScroll = () => {
    setIsScrolled(window.scrollY > 50);
  };

  const scrollToSection = (id) => {
    document.getElementById(id).scrollIntoView({ behavior: "smooth" });
  };

  const toggleMenu = () => {
    setIsMenuActive(!isMenuActive);
  };

  const handleAuthAction = () => {
    if (isLoggedIn) {
      setIsDropdownOpen(!isDropdownOpen); // Toggle dropdown for logged-in user
    } else {
      navigate("/auth"); // If not logged in, go to the auth page (sign up/login)
    }
  };

  const handleLogout = () => {
    logout(); // Call logout method from context
    window.location.reload();
    navigate("/auth"); // Redirect to the sign-up page after logout
  };

  const handleProfile = () => {
    navigate("/profile"); // Navigate to the profile page if logged in
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target) &&
        hamburgerRef.current &&
        !hamburgerRef.current.contains(event.target)
      ) {
        setIsMenuActive(false);
      }
    };

    document.addEventListener("click", handleClickOutside);
    window.addEventListener("scroll", handleScroll);

    return () => {
      document.removeEventListener("click", handleClickOutside);
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <nav
      className={`flex justify-between items-center p-5 from-[#f8f0fb] to-[#f9fae4] sticky top-0 z-50 border-b border-white/10 transition-all duration-100 ${
        isScrolled ? "text-white bg-[#262626] py-4" : "py-5 text-black"
      }`}
    >
      <div className="container mx-auto flex justify-between items-center w-full px-6">
        <div className="text-xl font-semibold tracking-wide font-sans">
          OGFLEET
        </div>

        {/* Hamburger Menu for Mobile with Bars (Icon) */}
        <div
          className="lg:hidden cursor-pointer"
          onClick={toggleMenu}
          ref={hamburgerRef}
        >
          {/* Hamburger Icon (3 Bars) */}
          <div className="w-6 h-0.5 bg-black mb-1"></div>
          <div className="w-6 h-0.5 bg-black mb-1"></div>
          <div className="w-6 h-0.5 bg-black"></div>
        </div>

        {/* Desktop Navigation Links and Dynamic Auth Button */}
        <div className="hidden lg:flex items-center gap-5 font-medium text-md font-sans">
          <ul className="flex gap-5">
            <li
              className="cursor-pointer hover:text-[#412fb3] transition-all duration-300"
              onClick={() => scrollToSection("home")}
            >
              Home
            </li>
            <li
              className="cursor-pointer hover:text-[#412fb3] transition-all duration-300"
              onClick={() => scrollToSection("stats")}
            >
              Stats
            </li>
            <li
              className="cursor-pointer hover:text-[#412fb3] transition-all duration-300"
              onClick={() => scrollToSection("about")}
            >
              About Us
            </li>
            <li
              className="cursor-pointer hover:text-[#412fb3] transition-all duration-300"
              onClick={() => scrollToSection("pricing")}
            >
              Pricing
            </li>
            <li
              className="cursor-pointer hover:text-[#412fb3] transition-all duration-300"
              onClick={() => scrollToSection("faq")}
            >
              FAQs
            </li>
            <li
              className="cursor-pointer hover:text-[#412fb3] transition-all duration-300"
              onClick={() => scrollToSection("contact")}
            >
              Contact
            </li>
          </ul>

          {/* Dynamic Auth Button (Desktop) */}
          <div className="relative">
            <button
              onClick={handleAuthAction}
              className={`text-white rounded-lg px-6 py-2 text-md font-medium transition-all duration-300 ${
                isLoggedIn
                  ? "bg-[#20182e] hover:bg-[#6832C5]"
                  : "bg-[#22195b] hover:bg-[#392c74]"
              }`}
            >
              {isLoggedIn ? "Profile" : "Sign Up"} {/* Dynamic button text */}
            </button>

            {isLoggedIn && isDropdownOpen && (
              <div
                ref={menuRef}
                className="absolute right-0 mt-2 bg-white border rounded-lg shadow-lg p-3 z-50"
              >
                <ul>
                  <li
                    className="cursor-pointer p-2 text-md font-medium"
                    onClick={handleProfile}
                  >
                    Profile
                  </li>
                  <li
                    className="cursor-pointer p-2 text-md font-medium"
                    onClick={handleLogout}
                  >
                    Logout
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuActive && (
            <motion.div
              className="lg:hidden absolute top-[60px] right-0 w-2/3  bg-white text-themepurple p-5 rounded-lg z-40"
              ref={menuRef}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.3 }}
            >
              <ul>
                <li
                  className="cursor-pointer p-3 font-sans font-medium text-lg"
                  onClick={() => scrollToSection("home")}
                >
                  Home
                </li>
                <li
                  className="cursor-pointer p-3 font-sans font-medium text-lg"
                  onClick={() => scrollToSection("stats")}
                >
                  Stats
                </li>
                <li
                  className="cursor-pointer p-3 font-sans font-medium text-lg"
                  onClick={() => scrollToSection("about")}
                >
                  About Us
                </li>
                <li
                  className="cursor-pointer p-3 font-sans font-medium text-lg"
                  onClick={() => scrollToSection("pricing")}
                >
                  Pricing
                </li>
                <li
                  className="cursor-pointer p-3 font-sans font-medium text-lg"
                  onClick={() => scrollToSection("faq")}
                >
                  FAQs
                </li>
                <li
                  className="cursor-pointer p-3 font-sans font-medium text-lg"
                  onClick={() => scrollToSection("contact")}
                >
                  Contact
                </li>
              </ul>
              {/* Mobile Dynamic Auth Button */}
              <button
                onClick={handleAuthAction}
                className={`w-full border-2 border-black rounded-full px-6 py-2 text-xl font-medium transition-all duration-300 ${
                  isLoggedIn
                    ? "bg-white text-black hover:bg-[#f1f1f1]"
                    : "bg-[#22195b] text-white hover:bg-[#392c74]"
                } mt-4`}
              >
                {isLoggedIn ? "Log Out" : "Sign Up"} {/* Dynamic button text */}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
};

export default Nav;
