import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { FaCog, FaChartBar, FaSearch, FaShieldAlt } from "react-icons/fa";

const services = [
  {
    title: "Drilling Optimization",
    description:
      "Utilizing AI to optimize drilling operations, reduce costs, and enhance safety with predictive analytics.",
    icon: <FaCog />,
  },
  {
    title: "Real-Time Monitoring",
    description:
      "Monitor drilling parameters in real-time and get immediate feedback to prevent issues before they arise.",
    icon: <FaChartBar />,
  },
  {
    title: "Problem Diagnosis & Solutions",
    description:
      "Identify complex problems in your drilling operations and offer precise, data-driven solutions powered by AI.",
    icon: <FaSearch />,
  },
  {
    title: "Safety Enhancement",
    description:
      "Enhance safety measures in drilling operations by predicting potential risks and offering safety protocols.",
    icon: <FaShieldAlt />,
  },
];

const Services = () => {
  const ref = useRef(null); // Reference for the section
  const isInView = useInView(ref, { once: true, margin: "-50px" }); // Detect if in view

  return (
    <section id="services" className="py-20 bg-white text-black" ref={ref}>
      <div className="container mx-auto px-4 md:px-6 lg:px-8 max-w-screen-xl">
        <motion.h2
          className="text-2xl text-center font-bold my-4 text-purple-700"
          initial={{ opacity: 0, y: -50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1.5, ease: "linear" }}
        >
          Our Services
        </motion.h2>
        <motion.p
          className="text-lg text-center mb-16 text-gray-600"
          initial={{ opacity: 0, y: -30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: "linear" }}
        >
          Leveraging advanced AI to solve the most complex drilling problems.
        </motion.p>

        {/* Grid layout for services */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="service-card bg-white shadow-lg rounded-xl p-6 transform hover:scale-105 transition-all duration-300 hover:bg-softBlack hover:text-softWhite group"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.8, ease: "linear", delay: index * 0.2 }}
            >
              <div className="text-3xl text-purple-700 mb-4 group-hover:text-purple-700">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4 group-hover:text-softWhite">
                {service.title}
              </h3>
              <p className="text-md text-gray-500 mb-4 group-hover:text-softWhite">
                {service.description}
              </p>

              {/* Hover button effect */}
              <motion.div
                className="mt-4 text-purple-700 font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                Learn More
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
