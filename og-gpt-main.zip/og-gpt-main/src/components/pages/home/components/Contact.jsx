import { MapPin, Phone, Mail } from "lucide-react";
import { motion } from "framer-motion"; // Import motion from framer-motion
const ContactUs = () => {
  return (
    <div id="contact" className="py-16 sm:my-20 px-4 bg-white">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-themepurple">Contact Us</h1>
      </div>

      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Location Box */}
          <a
            href="https://www.google.com/maps?q=198+West+21st+Street,+Suite+721,+New+York,+NY+10016"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white p-10 rounded-lg shadow-lg flex flex-col items-center transform hover:scale-105 transition-all duration-300 hover:bg-softBlack hover:text-softWhite group"
          >
            <MapPin className="text-4xl text-themepurple mb-4 group-hover:text-softWhite" />
            <h3 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-softWhite">
              Location
            </h3>
            <p className="text-gray-600 text-center group-hover:text-softWhite">
              198 West 21st Street, Suite 721 New York, NY 10016
            </p>
            <motion.div
              className="mt-4 text-themepurple font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              View on Map
            </motion.div>
          </a>

          {/* Phone Box */}
          <a
            href="tel:+1235235598"
            className="bg-white p-10 rounded-lg shadow-lg flex flex-col items-center transform hover:scale-105 transition-all duration-300 hover:bg-softBlack hover:text-softWhite group"
          >
            <Phone className="text-4xl text-themepurple mb-4 group-hover:text-softWhite" />
            <h3 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-softWhite">
              Phone
            </h3>
            <p className="text-gray-600 text-center group-hover:text-softWhite">
              +1235 2355 98
            </p>
            <motion.div
              className="mt-4 text-themepurple font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              Call Now
            </motion.div>
          </a>

          {/* Email Box */}
          <a
            href="mailto:info@ogfleet.com"
            className="bg-white p-10 rounded-lg shadow-lg flex flex-col items-center transform hover:scale-105 transition-all duration-300 hover:bg-softBlack hover:text-softWhite group"
          >
            <Mail className="text-4xl text-themepurple mb-4 group-hover:text-softWhite" />
            <h3 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-softWhite">
              Email
            </h3>
            <p className="text-gray-600 text-center group-hover:text-softWhite">
              info@ogfleet.com
            </p>
            <motion.div
              className="mt-4 text-themepurple font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              Send Email
            </motion.div>
          </a>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
