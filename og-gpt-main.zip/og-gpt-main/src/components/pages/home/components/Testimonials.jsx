import React, { useState } from "react";
import { motion } from "framer-motion";
import { FaChevronLeft, FaChevronRight } from "react-icons/fa"; // Import icons from react-icons/fa

const testimonials = [
  {
    quote:
      "Dekanex helped us build a solid online presence. Their expertise in SEO and branding is unmatched!",
    name: "John Doe",
    title: "CEO, Tech Company",
  },
  {
    quote:
      "Fantastic service! Our website was developed with great attention to detail, and we saw results immediately.",
    name: "Jane Smith",
    title: "Marketing Manager, E-commerce",
  },
  {
    quote:
      "The team at Dekanex is professional and efficient. They made sure our security was top-notch.",
    name: "Ali Khan",
    title: "CTO, Startup",
  },
  {
    quote:
      "I was impressed by their commitment to quality and customer satisfaction. Truly a professional team!",
    name: "Sara Lee",
    title: "Founder, Fashion Brand",
  },
  {
    quote:
      "The project was completed ahead of schedule and exceeded expectations. Highly recommended!",
    name: "Mike Johnson",
    title: "Project Manager, Finance Corp",
  },
  {
    quote:
      "Great experience working with Dekanex! Their team is responsive and knowledgeable.",
    name: "Laura White",
    title: "Product Lead, Software Co.",
  },
];

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setCurrentIndex(
      (prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length
    );
  };

  return (
    <div className="container mx-auto p-4 relative sm:mb-20 max-w-6xl overflow-hidden py-10">
      {/* Testimonials Heading with Gradient Background */}
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-[rgb(104,50,197)] text-opacity-80 bg-gradient-to-r from-indigo-600 to-indigo-900 bg-clip-text text-transparent">
          What Our Clients Say
        </h2>
        <p className="text-sm text-gray-600 mt-2">
          Discover how Dekanex has helped businesses grow with tailored AI,
          security, and web solutions.
        </p>
      </div>

      {/* Previous Button */}
      <button
        className="absolute top-1/2 left-4 transform -translate-y-1/2 bg-white text-black rounded-full p-3 z-10"
        onClick={prevSlide}
      >
        <FaChevronLeft size={20} />
      </button>

      {/* Testimonial Slider */}
      <motion.div
        className="flex transition-transform duration-500"
        initial={{ x: 0 }}
        animate={{ x: (-currentIndex * 100) / 2 + "%" }}
        exit={{ opacity: 0 }}
      >
        {testimonials.map((testimonial, index) => {
          const isNextOrPrev =
            index === (currentIndex + 1) % testimonials.length ||
            index ===
              (currentIndex - 1 + testimonials.length) % testimonials.length;

          return (
            <div
              key={index}
              className={`flex-none w-full sm:w-1/2 mx-4 bg-softBlack rounded-lg shadow-lg p-4 text-center ${
                isNextOrPrev ? "blur-sm" : ""
              }`}
            >
              <p className="text-lg italic text-softWhite mb-4">
                "{testimonial.quote}"
              </p>
              <h4 className="font-bold text-themepurple text-xl">{testimonial.name}</h4>
              <h5 className="text-softWhite">{testimonial.title}</h5>
            </div>
          );
        })}
      </motion.div>

      {/* Next Button */}
      <button
        className="absolute top-1/2 right-4 transform -translate-y-1/2 bg-white text-black rounded-full p-3 z-10"
        onClick={nextSlide}
      >
        <FaChevronRight size={24} />
      </button>
    </div>
  );
};

export default Testimonials;
