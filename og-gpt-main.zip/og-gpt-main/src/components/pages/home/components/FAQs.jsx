import {
  CheckCircle,
  Calculator,
  Globe,
  Database,
  AlertCircle,
  Settings,
} from "lucide-react";

const FAQ = () => {
  const questions = [
    {
      question:
        "What is OGFLEET, and how does it assist in drilling operations?",
      answer:
        "OGFLEET is a petroleum chatbot powered by advanced AI, designed to answer complex drilling questions, provide operational insights, and assist in real-time decision-making for drilling tasks.",
      icon: <CheckCircle className="w-6 h-6 text-indigo-700" />, // Example icon for OGFLEET
    },
    {
      question:
        "Can OGFLEET handle complex mathematical calculations related to drilling?",
      answer:
        "Yes, OGFLEET is equipped to solve advanced mathematical calculations with high accuracy, including pressure differentials, mud weight, and other drilling-related parameters.",
      icon: <Calculator className="w-6 h-6 text-indigo-700" />, // Example icon for calculations
    },
    {
      question: "How accurate are the answers provided by OGFLEET?",
      answer:
        "OGFLEET leverages GPT technology combined with petroleum engineering expertise to provide answers with high accuracy, ensuring reliability for drilling operations.",
      icon: <CheckCircle className="w-6 h-6 text-indigo-700" />, // Example icon for accuracy
    },
    {
      question: "Can OGFLEET integrate with existing drilling systems?",
      answer:
        "Yes, OGFLEET can integrate seamlessly with existing systems to enhance productivity and operational efficiency in drilling projects.",
      icon: <Settings className="w-6 h-6 text-indigo-700" />, // Example icon for integration
    },
    {
      question: "What kind of data does OGFLEET require to provide insights?",
      answer:
        "OGFLEET utilizes data such as well logs, drilling parameters, and real-time telemetry to deliver actionable insights and optimize operations.",
      icon: <Database className="w-6 h-6 text-indigo-700" />, // Example icon for data
    },
    {
      question: "Does OGFLEET support multiple languages for global teams?",
      answer:
        "Yes, OGFLEET is designed to support multiple languages, ensuring teams across the globe can use it effectively.",
      icon: <Globe className="w-6 h-6 text-themepurple" />, // Example icon for language support
    },
    {
      question: "Can OGFLEET predict potential drilling hazards?",
      answer:
        "OGFLEET uses advanced analytics to identify potential hazards such as wellbore instability, kick detection, and formation damage, helping mitigate risks in advance.",
      icon: <AlertCircle className="w-6 h-6 text-themepurple" />, // Example icon for hazards
    },
    {
      question: "Is OGFLEET customizable to specific drilling requirements?",
      answer:
        "Yes, OGFLEET can be customized to meet specific drilling needs, including specialized calculations, workflows, and integration with custom tools.",
      icon: <Settings className="w-6 h-6 text-themepurple" />, // Example icon for customization
    },
  ];

  return (
    <section id="faq" className=" bg-gradient-to-r from-[#f8f0fb] to-[#f9fae4] bg-gray-50 py-24 sm:my-24 px-4">
      <h2 className="text-3xl text-themepurple font-bold mb-10 text-center">
        Frequently Asked Questions
      </h2>
      <p className="text-md text-center mb-12 text-gray-600">
        Here you'll find answers to the most common questions about OGFLEET.
        Whether you're new to the platform<br/>or looking for more detailed
        information.
      </p>
      <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-6">
        {questions.map((item, index) => (
          <div
            className="flex flex-col sm:flex-row items-start bg-white p-6 rounded-lg shadow-md space-y-4 sm:space-y-0 sm:space-x-6"
            key={index}
          >
            {/* Icon */}
            <div className="flex-shrink-0">{item.icon}</div>
            {/* Question and answer */}
            <div>
              <h3 className="text-lg font-medium text-themepurple mb-2">
                {item.question}
              </h3>
              <p className="text-gray-600">{item.answer}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default FAQ;
