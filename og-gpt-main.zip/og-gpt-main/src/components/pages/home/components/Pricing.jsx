import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { FaFire } from "react-icons/fa"; // Importing a fire icon for "Popular" label
import { useAuth } from "../../../../context/AuthContext";

const Pricing = () => {
  const { isAuthenticated, setRedirectAfterLogin } = useAuth();
  const navigate = useNavigate();

  const handlePurchase = (plan) => {
    if (!isAuthenticated) {
      setRedirectAfterLogin(`/checkout?plan=${plan}`); // Save intended route
      navigate("/auth");
    } else {
      navigate(`/checkout?plan=${plan}`);
    }
  };

  return (
    <div className="bg-gradient-to-r from-[#f8f0fb] to-[#f9fae4] py-20 min-h-screen flex justify-center items-center bg-white sm:my-20 px-4">
      <section id="pricing" className="text-center max-w-6xl mx-auto">
        {/* Heading with updated size */}
        <h2 className="text-3xl font-bold mb-4 text-themepurple">
          Choose Plan
        </h2>

        {/* Paragraph for additional information */}
        <p className="text-sm text-gray-600 mb-24">
          Find the perfect plan for reliable, affordable hosting.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Basic Plan */}
          <motion.div
            className="bg-gray-50 rounded-lg p-8 w-full transform transition duration-500 hover:scale-105 hover:shadow-xl"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="mb-6">
              <h4 className="text-xl font-medium text-indigo-700">Basic</h4>
              <p className="text-gray-600 text-sm">
                for small websites or blogs
              </p>
            </div>
            <p className="text-5xl font-semibold text-indigo-700">
              $2<sub className="text-base text-gray-500">/month</sub>
            </p>

            <motion.ul
              className="space-y-4 mt-6 text-left text-sm text-gray-600"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2, staggerChildren: 0.1 }}
            >
              {[
                "1 domain name",
                "10 GB of disk space",
                "100GB of bandwidth",
                "1 MySQL database",
                "5 email accounts",
                "cPanel control panel",
                "Free SSL certificate",
                "24/7 support",
                "Free CDN",
                "Daily backups",
                "Advanced security features",
              ].map((item, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                  className={`${
                    item.includes("Free CDN") ||
                    item.includes("Daily backups") ||
                    item.includes("Advanced security features")
                      ? "line-through text-gray-400"
                      : ""
                  }`}
                >
                  <strong>{item.split(" ")[0]}</strong> {item.slice(1)}
                </motion.li>
              ))}
            </motion.ul>

            <button
              onClick={() => handlePurchase("basic")}
              className="mt-6 w-full py-3 rounded-lg bg-indigo-600 text-white text-lg font-semibold"
            >
              SELECT
            </button>
          </motion.div>

          {/* Standard Plan */}
          <motion.div
            className="relative border-4 border-themepurple bg-white shadow-lg scale-105 rounded-lg p-8 w-full transform transition duration-500 hover:scale-105 hover:shadow-xl"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            {/* Popular Label with Icon */}
            <div className="absolute top-[-25px] left-1/2 transform -translate-x-1/2 flex items-center justify-center bg-indigo-600 text-white py-2 px-4 rounded-full">
              <FaFire className="mr-2 text-orange-500" />
              <h1 className="text-lg font-semibold">Popular</h1>
            </div>

            <div className="mb-6">
              <h4 className="text-xl font-medium text-[#412fb3]">Standard</h4>
              <p className="text-gray-600 text-sm">
                for medium-sized businesses
              </p>
            </div>
            <p className="text-5xl font-semibold text-[#412fb3]">
              $5<sub className="text-base text-gray-500">/month</sub>
            </p>

            <motion.ul
              className="space-y-4 mt-6 text-left text-sm text-gray-600"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, staggerChildren: 0.1 }}
            >
              {[
                "Unlimited domain name",
                "50 GB of disk space",
                "500GB of bandwidth",
                "10 MySQL databases",
                "50 email accounts",
                "cPanel control panel",
                "Free SSL certificate",
                "24/7 support",
                "Free CDN",
                "Daily backups",
                "Priority support",
              ].map((item, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className={`${
                    item.includes("Free CDN") || item.includes("Daily backups")
                      ? "line-through text-gray-400"
                      : ""
                  }`}
                >
                  <strong>{item.split(" ")[0]}</strong> {item.slice(1)}
                </motion.li>
              ))}
            </motion.ul>

            <button
              onClick={() => handlePurchase("standard")}
              className="mt-6 w-full py-3 rounded-lg bg-[#412fb3] text-white text-lg font-semibold"
            >
              SELECT
            </button>
          </motion.div>

          {/* Premium Plan */}
          <motion.div
            className="bg-gray-50  rounded-lg p-8 w-full transform transition duration-500 hover:scale-105 hover:shadow-xl"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="mb-6">
              <h4 className="text-xl font-medium text-indigo-700">Premium</h4>
              <p className="text-gray-600 text-sm">for small businesses</p>
            </div>
            <p className="text-5xl font-semibold text-indigo-700">
              $10<sub className="text-base text-gray-500">/month</sub>
            </p>

            <motion.ul
              className="space-y-4 mt-6 text-left text-sm text-gray-600"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, staggerChildren: 0.1 }}
            >
              {[
                "Unlimited domain name",
                "100 GB of disk space",
                "1TB of bandwidth",
                "Unlimited MySQL databases",
                "Unlimited email accounts",
                "cPanel control panel",
                "Free SSL certificate",
                "24/7 priority support",
                "Advanced security features",
                "Free CDN",
                "Daily backups",
              ].map((item, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                >
                  <strong>{item.split(" ")[0]}</strong> {item.slice(1)}
                </motion.li>
              ))}
            </motion.ul>

            <button
              onClick={() => handlePurchase("premium")}
              className="mt-6 w-full py-3 rounded-lg bg-indigo-600 text-white text-lg font-semibold"
            >
              SELECT
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Pricing;
