import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { FaUserAlt, FaFolder, FaFileAlt, FaPencilAlt } from "react-icons/fa"; // Import the icons

const Stats = () => {
  const data = [
    { number: "1.5M+", label: "Active Users", icon: <FaUserAlt size={40} /> },
    { number: "12", label: "Prompt Categories", icon: <FaFolder size={40} /> },
    { number: "100+", label: "Prompts", icon: <FaFileAlt size={40} /> },
    { number: "15", label: "Writing Styles", icon: <FaPencilAlt size={40} /> },
  ];

  const [animatedNumbers, setAnimatedNumbers] = useState(
    data.map((item) => ({ ...item, displayedNumber: "0" }))
  );

  useEffect(() => {
    const statsCards = document.querySelectorAll(".stats-card");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            animateNumbers();
          }
        });
      },
      { threshold: 0.2 }
    );

    statsCards.forEach((card) => observer.observe(card));
    return () => {
      statsCards.forEach((card) => observer.unobserve(card));
    };
  }, []);

  const animateNumbers = () => {
    setAnimatedNumbers((prevState) =>
      prevState.map((item) => {
        if (item.number.includes("M")) {
          return { ...item, displayedNumber: "1.5" }; // Simple animation for the number
        }
        if (item.number.includes("+")) {
          return { ...item, displayedNumber: item.number.replace("+", "") }; // Removing "+" sign
        }
        return { ...item, displayedNumber: item.number };
      })
    );
  };

  return (
    <div id="stats" className="bg-white my-32 py-12">
      <div className="container mx-auto text-center">
        {/* Main Title */}
        <h1 className="text-2xl font-bold text-themepurple">
          Power in Numbers
        </h1>

        {/* Subheading Paragraph */}
        <p className="text-md text-gray-600 my-6 px-10">
          OGFLEET's technology drives results, optimizes processes,<br/> and fuels
          business growth.
        </p>

        <div className="flex flex-wrap justify-center gap-8">
          {animatedNumbers.map((item, index) => (
            <motion.div
              className="stats-card bg-softBlack p-8 mx-6 mt-10 rounded-lg text-center shadow-sm hover:shadow-lg transition-all duration-300 transform hover:scale-105 hover:rotate-3 opacity-0 translate-y-8 w-full sm:w-1/2 md:w-1/3 lg:w-1/6 h-48 flex flex-col justify-center items-center"
              key={index}
              initial={{ opacity: 0, translateY: 30 }}
              animate={{ opacity: 1, translateY: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="text-4xl mb-4 text-softWhite">{item.icon}</div>
              <h2 className="text-4xl font-semibold text-softWhite">
                {item.displayedNumber}
              </h2>
              <p className="text-lg text-gray-200">{item.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Stats;
