import React from "react";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Aboutus from "./components/Aboutus";
import Stats from "./components/State";
import Pricing from "./components/Pricing";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import Testimonials from "./components/Testimonials";
import FAQs from "./components/FAQs";
import Services from "./components/Services";
function Home() {
  return (
    <div>
      <Nav />
      <Hero />
      <Services/>
      <Aboutus />
      <Stats />
      <Pricing />
      <Testimonials />
      <FAQs />
      <Contact />
      <Footer />
    </div>
  );
}

export default Home;
