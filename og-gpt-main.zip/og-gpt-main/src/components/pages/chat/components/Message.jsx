import React from 'react';

const Message = ({ content, sender }) => (
  <div className={`message ${sender === 'user' ? 'bg-[#424242] text-white self-end' : 'bg-[#333333] text-[#cfcfcf] self-start'} m-2 p-2 rounded-lg max-w-[75%] break-words`}>
    {content}
  </div>
);

export default Message;
