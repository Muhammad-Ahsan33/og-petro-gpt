import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import profileIcon from '../../../../assets/profile-circle-svgrepo-com.svg';
import menuIcon from '../../../../assets/icons8-menu.svg';
import newChatIcon from '../../../../assets/chat-new-svgrepo-com.svg';
import { useAuth } from "../../../../context/AuthContext";

const Navbar = ({ isOpen, toggleSidebar, startNewChat, model, setModel }) => {
  const [showLogout, setShowLogout] = useState(false); 
  const navigate = useNavigate();
  const profileContainerRef = useRef(null); 
  const {logout} = useAuth();

  const handleLogout = () => {
    logout()
    navigate('/auth');
  };

  const toggleLogoutMenu = () => {
    setShowLogout(!showLogout);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (profileContainerRef.current && !profileContainerRef.current.contains(event.target)) {
        setShowLogout(false); // Close the logout menu if click is outside
      }
    };

    document.addEventListener('click', handleClickOutside);

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []); 

  return (
    <div className="flex items-center p-[18px_20px] bg-[#212121] text-white sticky top-0 z-100">
      {/* Only show menu and new chat icons if the sidebar is closed */}
      {!isOpen && (
        <>
          <img 
            src={menuIcon} 
            alt="Menu" 
            className="w-6 h-6 cursor-pointer mr-4 transition-transform duration-300 hover:scale-110 z-10"
            onClick={toggleSidebar} 
          />
          <img 
            src={newChatIcon} 
            alt="New Chat" 
            className="w-6 h-6 cursor-pointer mr-4 transition-transform duration-300 hover:scale-110 z-10"
            onClick={startNewChat} 
          />
        </>
      )}

      {/* Model Select (always visible, even if sidebar is open) */}
      <select
        className="bg-[#333333] text-white border-none rounded-md p-2 text-base cursor-pointer ml-2 opacity-100 transition-opacity duration-400 ease-in-out z-10"
        value={model}
        onChange={(e) => setModel(e.target.value)}
      >
        <option value="Drilling Fluids">Drilling Fluids</option>
        <option value="Reservoir">Reservoir</option>
        <option value="Manufacturing">Manufacturing</option>
      </select>

      {/* Title (OG FLEET) - Hide on small screens */}
      <h1 className="flex-grow text-[1.5rem] font-bold text-center ml-[-160px] md:block hidden">OG FLEET</h1>

      {/* Profile Icon (Aligned to the right) */}
      <div className="relative ml-auto" ref={profileContainerRef}>
        <img
          src={profileIcon}
          alt="Profile"
          className="w-6 h-6 cursor-pointer mr-4 transition-transform duration-300 hover:scale-110 z-10"
          onClick={toggleLogoutMenu}
        />
        {showLogout && (
          <div className="absolute top-9 right-0 bg-[#333333] rounded-md p-1 w-32 z-10">
            <button 
              onClick={handleLogout} 
              className="w-full bg-transparent text-white py-2 text-base cursor-pointer hover:bg-[#555555] rounded-md"
            >
              Logout
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Navbar;
