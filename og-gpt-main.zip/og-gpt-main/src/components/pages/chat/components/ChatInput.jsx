import React, { useState, useRef, useEffect } from 'react';
import sendIcon from '../../../../assets/send-alt-2-svgrepo-com.svg';

const ChatInput = ({ onSend }) => {
    const [input, setInput] = useState('');
    const [isFocused, setIsFocused] = useState(false); // Track focus state
    const [isScrolling, setIsScrolling] = useState(false); // Track if scrollbar is visible
    const textareaRef = useRef(null);

    // Detect scrollbar appearance
    useEffect(() => {
        const textarea = textareaRef.current;
        const handleResize = () => {
            if (textarea) {
                setIsScrolling(textarea.scrollHeight > textarea.clientHeight);
            }
        };

        // Check when component mounts
        handleResize();

        // Resize observer to track changes
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleSend = () => {
        if (input.trim()) {
            onSend(input);
            setInput('');
            if (textareaRef.current) {
                textareaRef.current.style.height = 'auto';
            }
        }
    };

    const handleChange = (e) => {
        setInput(e.target.value);
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 100)}px`;  
        }
    };

    const handleFocus = () => {
        setIsFocused(true); // When focused, set state to true
    };

    const handleBlur = () => {
        setIsFocused(false); // When blurred, set state to false
    };

    return (
        <div
            className={`flex items-center bg-[#2f2f2f] sticky bottom-[14px] mx-auto p-2 box-border justify-center transition-all duration-300 ease-in-out
                ${isFocused ? 'w-full sm:w-full lg:w-3/5' : 'sm:w-full lg:w-2/5'}
                ${isScrolling ? 'rounded-[8px]' : 'rounded-[16px]'} // Conditional border-radius
                overflow-hidden`} // Prevent overflow for consistent rounded corners
        >
            <textarea
                ref={textareaRef}
                value={input}
                onChange={handleChange}
                onFocus={handleFocus}
                onBlur={handleBlur}
                onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault(); 
                        handleSend();
                    }
                }}
                placeholder="Ask Petroleum BOT"
                rows={1}
                className="input flex-1 bg-transparent text-white p-2 text-sm outline-none mr-2 resize-none overflow-y-auto max-h-[100px] transition-all duration-300 ease-in-out"
            />
            <button onClick={handleSend} className="bg-transparent border-none cursor-pointer">
                <img src={sendIcon} alt="Send" className="transition-transform duration-300 ease-in-out hover:scale-110" />
            </button>
        </div>
    );
};

export default ChatInput;
