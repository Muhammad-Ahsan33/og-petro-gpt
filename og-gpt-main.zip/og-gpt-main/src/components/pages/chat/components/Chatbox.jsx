import React, { useEffect, useRef } from "react";
import Message from "./Message";

const Chatbox = ({ messages }) => {
  const chatboxRef = useRef(null);

  const scrollToBottom = () => {
    if (chatboxRef.current) {
      chatboxRef.current.scrollTop = chatboxRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]); // Reacts to changes in `messages`

  return (
    <div
      className="chatbox flex-1 flex flex-col p-2 bg-[#212121] overflow-hidden overflow-y-auto justify-start items-center w-full md:w-3/5 mx-auto scroll-smooth"
      ref={chatboxRef}
    >
      {messages.length === 0 ? (
        <div className="flex flex-col justify-center items-center h-full text-gray-400 text-center italic">
          <p className="text-lg md:text-xl font-medium">Start a conversation!</p>
          <p className="text-sm md:text-base">
            Select a model and ask your questions.
          </p>
        </div>
      ) : (
        messages.map((msg, index) => (
          msg.sender === "system" && msg.message.includes("You are using the") ? (
            <div
              key={index}
              className="text-blue-500 text-center italic font-bold p-4 my-4 rounded-lg w-full box-border text-base shadow-lg"
            >
              {msg.message}
            </div>
          ) : (
            <Message key={index} content={msg.message} sender={msg.sender} />
          )
        ))
      )}
    </div>
  );
};

export default Chatbox;
