import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import menuIcon from '../../../../assets/icons8-menu.svg';
import newChatIcon from '../../../../assets/chat-new-svgrepo-com.svg';
import dotsIcon from '../../../../assets/dots-vertical-svgrepo-com.svg'; // 3 dots SVG
import renameIcon from '../../../../assets/rename-svgrepo-com.svg'; // Rename SVG
import deleteIcon from '../../../../assets/delete-2-svgrepo-com.svg'; // Delete SVG

const Sidebar = ({
  isOpen,
  toggleSidebar,
  startNewChat,
  chatHistory,
  handleHistoryClick,
  currentConversationIndex,
  renameChat,
  deleteChat,
  setCurrentConversationIndex, // Added this prop to update currentConversationIndex
}) => {
  const [showOptionsIndex, setShowOptionsIndex] = useState(null);
  const [isRenaming, setIsRenaming] = useState(false);
  const [renameInput, setRenameInput] = useState('');
  const optionsRef = useRef(null);
  const navigate = useNavigate();

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (optionsRef.current && !optionsRef.current.contains(event.target)) {
        setShowOptionsIndex(null);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  const handleShowOptions = (index) => {
    setShowOptionsIndex(index === showOptionsIndex ? null : index); // Toggle visibility of options
  };

  const handleRenameClick = (index) => {
    setIsRenaming(true);
    setRenameInput(chatHistory[index].title); // Pre-fill with current title
    setShowOptionsIndex(null); // Close dropdown
  };

  const handleRenameSubmit = async (index) => {
    const chatId = chatHistory[index].id;
    try {
      await renameChat(chatId, renameInput); // from App.js
    } catch (error) {
      console.error('Error renaming chat:', error);
    } finally {
      setIsRenaming(false);
    }
  };

  const handleDeleteClick = async (index) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this chat?');
    if (!confirmDelete) return;

    const chatId = chatHistory[index].id;
    try {
      await deleteChat(chatId); // from App.js
      // If the deleted chat was the current conversation, clear it
      if (currentConversationIndex === index) {
        setCurrentConversationIndex(null); // or set to a default chat index if necessary
      }
    } catch (error) {
      console.error('Error deleting chat:', error);
    } finally {
      setShowOptionsIndex(null); // Close dropdown
    }
  };

  const navigateToProfile = () => {
    navigate('/profile');
  };

  return (
    <div className={`w-[250px] bg-[#171717] text-white flex flex-col justify-between transition-transform duration-[0.4s] ease-in-out fixed h-full z-[200] ${isOpen ? 'transform translate-x-0' : 'transform -translate-x-full'}`}>
      {/* Top Section */}
      <div className="flex items-center p-[27.5px_10px_10px_10px] justify-between">
        <img src={menuIcon} alt="Menu" className="w-[25px] h-[25px] cursor-pointer mr-[15px]" onClick={toggleSidebar} />
        <img src={newChatIcon} alt="New Chat" className="w-[25px] h-[25px] cursor-pointer mr-[15px]" onClick={startNewChat} />
      </div>

      {/* History Section */}
      <div className="history flex-1 overflow-y-auto p-[10px]">
        <h3 className="text-[1.1rem] font-bold mb-[10px]">History</h3>
        {chatHistory.map((chat, index) => (
          <div
            key={chat.id}
            className={`relative p-[8px] rounded-[8px] cursor-pointer transition-colors duration-[0.3s] flex justify-between items-center ${currentConversationIndex === index ? 'bg-[#212121]' : 'hover:bg-[#212121]'}`}
            onClick={() => handleHistoryClick(index)}
          >
            {isRenaming && currentConversationIndex === index ? (
              <input
                type="text"
                value={renameInput}
                onChange={(e) => setRenameInput(e.target.value)}
                onBlur={() => handleRenameSubmit(index)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleRenameSubmit(index);
                  if (e.key === 'Escape') setIsRenaming(false);
                }}
                autoFocus
                className="bg-gray-600 text-white p-[8px] rounded-[8px] w-full"
              />
            ) : (
              <span>{chat.title}</span>
            )}
            <img
              src={dotsIcon}
              alt="More options"
              className="w-[15px] h-[12px] cursor-pointer"
              onClick={(e) => {
                e.stopPropagation(); // Prevent the click from propagating to the history item
                handleShowOptions(index);
              }}
            />
            {showOptionsIndex === index && (
              <div className="absolute top-0 right-0 bg-[#333333] rounded-[4px] p-[5px] w-[100px] shadow-md z-[10] max-h-[150px] overflow-y-auto" ref={optionsRef}>
                <div className="flex items-center p-[8px_0] text-white cursor-pointer hover:bg-[#555555] rounded-[4px]" onClick={() => handleRenameClick(index)}>
                  <img src={renameIcon} alt="Rename" className="w-[18px] h-[18px] mr-[8px]" />
                  Rename
                </div>
                <div className="flex items-center p-[8px_0] text-red-500 cursor-pointer hover:bg-[#555555] rounded-[4px]" onClick={() => handleDeleteClick(index)}>
                  <img src={deleteIcon} alt="Delete" className="w-[18px] h-[18px] mr-[8px]" />
                  Delete
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Settings Section */}
      <div className="p-[10px] flex flex-col gap-[10px] mt-auto">
        <button className="bg-[#333333] text-white border-none p-[10px] m-0 cursor-pointer rounded-[4px] text-center transition-colors duration-[0.3s] w-full hover:bg-[#555555]" onClick={navigateToProfile}>
          Settings
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
