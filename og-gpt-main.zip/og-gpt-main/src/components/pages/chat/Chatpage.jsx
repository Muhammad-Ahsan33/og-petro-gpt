import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Chatbox from './components/Chatbox';
import ChatInput from './components/ChatInput';
import { fetchUserChats, fetchChatMessages, submitQuery, createChat, renameChatAPI, deleteChatAPI, suggestTitle } from '../../api';
import { useAuth } from "../../../context/AuthContext";

function ChatPage() {
  // State for chat functionality
  const [isOpen, setIsOpen] = useState(true);
  const [model, setModel] = useState('Drilling Fluids');
  const [conversations, setConversations] = useState([]);
  const [currentConversationIndex, setCurrentConversationIndex] = useState(0);
  const { user, isLoggedIn } = useAuth();

  // Toggles the sidebar
  const toggleSidebar = () => setIsOpen(!isOpen);

  // Fetch user chats on component mount
  useEffect(() => {
    if (isLoggedIn && user) {
      const fetchChats = async () => {
        try {
          const response = await fetchUserChats(user);
          setConversations(response.chats.map((chat) => ({ ...chat, messages: [] })));
        } catch (error) {
          console.error('Error fetching user chats:', error);
        }
      };
      fetchChats();
    }
  }, [isLoggedIn, user]);

  // Start a new chat
  const startNewChat = async () => {
    if (!isLoggedIn || !user) {
      console.error('User not logged in');
      return;
    }

    try {
      const response = await createChat(user, `Conversation ${conversations.length + 1}`, 1)

      const newChat = {
        id: response.chat_id,
        title: `Conversation ${conversations.length + 1}`,
        messages: [],
      };
      setConversations([newChat, ...conversations]);
      setCurrentConversationIndex(0);
    } catch (error) {
      console.error('Error creating chat:', error);
    }
  };

  // Send a message to the conversation
  const sendMessage = async (text) => {
    if (!conversations[currentConversationIndex]) {
      console.error('No active conversation');
      return;
    }

    const chatId = conversations[currentConversationIndex].id;

    try {
      // Add user message locally
      setConversations((prev) => {
        const updated = [...prev];
        updated[currentConversationIndex] = {
          ...updated[currentConversationIndex],
          messages: [
            ...updated[currentConversationIndex].messages,
            { sender: 'user', message: text },
          ],
        };
        return updated;
      });

      // Call query API for AI response
      const response = await submitQuery(chatId, text);

      // Add AI response to messages
      setConversations((prev) => {
        const updated = [...prev];
        updated[currentConversationIndex] = {
          ...updated[currentConversationIndex],
          messages: [
            ...updated[currentConversationIndex].messages,
            { sender: 'ai', message: response.ai_response },
          ],
        };
        return updated;
      });

      // If it's the first message in this chat, rename the chat
      if (conversations[currentConversationIndex].messages.length === 0) {
        const titleResponse = await suggestTitle(chatId, text);
        const newTitle = titleResponse.title || 'Untitled Chat';

        await renameChat(chatId, newTitle);
      }

    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  // Handle the model selection change
  const handleModelChange = (newModel) => {
    if (newModel !== model) {
      const updatedConversations = [...conversations];
      updatedConversations[currentConversationIndex].messages.push({
        sender: 'system',
        message: `You are using the ${newModel} model.`,
      });
      setConversations(updatedConversations);
      setModel(newModel);
    }
  };

  // Handle conversation history click
  const handleHistoryClick = async (index) => {
    setCurrentConversationIndex(index);
    const chatId = conversations[index].id;

    try {
      const response = await fetchChatMessages(chatId);
      const updatedConversations = [...conversations];
      updatedConversations[index].messages = response.messages;
      setConversations(updatedConversations);
    } catch (error) {
      console.error('Error fetching chat messages:', error);
    }
  };

  const renameChat = async (chatId, newTitle) => {
    try {
      await renameChatAPI(chatId, newTitle);

      setConversations((prev) =>
        prev.map((chat) =>
          chat.id === chatId ? { ...chat, title: newTitle } : chat
        )
      );
    } catch (error) {
      console.error('Error renaming chat:', error);
    }
  };

  const deleteChat = async (chatId) => {
    try {
      await deleteChatAPI(chatId);
      const updatedConversations = conversations.filter((chat) => chat.id !== chatId);
      setConversations(updatedConversations); // Update state by removing chat
    } catch (error) {
      console.error('Error deleting chat:', error);
    }
  };

  return (
    <div className={`app ${isOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
      <Sidebar
        isOpen={isOpen}
        toggleSidebar={toggleSidebar}
        startNewChat={startNewChat}
        chatHistory={conversations}
        handleHistoryClick={handleHistoryClick}
        currentConversationIndex={currentConversationIndex}
        renameChat={renameChat}
        deleteChat={deleteChat}
      />
      <div className="main-content">
        <Navbar
          isOpen={isOpen}
          toggleSidebar={toggleSidebar}
          startNewChat={startNewChat}
          model={model}
          setModel={handleModelChange}
        />
        <Chatbox messages={conversations[currentConversationIndex]?.messages || []} selectedModel={model} />
        <ChatInput onSend={sendMessage} />
      </div>
    </div>
  );
}

export default ChatPage;
