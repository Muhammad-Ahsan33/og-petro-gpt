import React, { useState } from "react";
import { motion } from "framer-motion";
import { useAuth } from "../../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { signUpUser, signInUser } from "../../api.js";

const AuthPage = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [error, setError] = useState("");
  const { login, logout, isLoggedIn, redirectAfterLogin, setRedirectAfterLogin } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await signInUser(email, password); // Call login API
      if (response.message == 'Sign-in successful') {
        login(response.user_id);
        toast.success("Login Successful!");
        navigate(redirectAfterLogin || "/chat"); // Redirect after login
      } else {
        setError("Invalid email or password.");
      }
    } catch (err) {
      setError("An error occurred while logging in.");
    }
  };  

  const handleSignUp = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError("Passwords do not match!");
      return;
    }
  
    try {
      const response = await signUpUser(fullName, email, password); // Call signup API
      if (response.message == 'Sign-up successful') {
        toast.success("Account created successfully! Please log in.");
        setIsSignUp(false); // Switch to login form
      } else {
        setError("Sign-up failed.");
      }
    } catch (err) {
      setError("An error occurred while signing up.");
    }
  };

  const handleLogout = () => {
    logout();
    setEmail("");
    setPassword("");
    setError("");
    navigate("/"); // Redirect to home or login page on logout
  };

  const toggleForm = () => {
    setIsSignUp((prev) => !prev);
    setError("");
  };

  return (
    <div className="bg-gradient-to-r from-[#f8f0fb] to-[#f9fae4] min-h-screen flex items-center justify-center bg-[#22195b] p-4">
      <div className="relative w-full max-w-5xl bg-[#ffffff] rounded-xl shadow-lg overflow-hidden flex">
        {/* Left Section */}
        <motion.div
          className="hidden md:flex justify-center items-center w-1/2 bg-cover bg-center text-white"
          style={{
            backgroundImage: isSignUp
              ? "url('https://images.unsplash.com/photo-1673255745677-e36f618550d1?q=80&w=2080&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')"
              : "url('https://images.unsplash.com/photo-1684369585080-11700ba4a9e9?q=80&w=1934&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')",
          }}
          key={isSignUp ? "signup" : "login"}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          <div className="space-y-5 h-full flex-col flex justify-center items-center bg-black/40 p-6 rounded-xl">
            <h2 className="text-3xl font-bold text-[#f8f9fc]">
              {isSignUp ? "Join OG-FLEET" : "Welcome Back"}
            </h2>
            <p className="text-lg text-center text-[#d1d5db]">
              {isSignUp
                ? "Be part of a future-driven community. Sign up today and unlock innovation."
                : "Log in to access your account and explore new possibilities."}
            </p>
          </div>
        </motion.div>

        {/* Right Section */}
        <div className="w-full md:w-1/2 flex flex-col justify-center items-center p-8 space-y-6 bg-[#ffffff]">
          <h2 className="text-3xl font-bold text-themepurple">
            {isSignUp ? "Sign Up" : "Login"}
          </h2>

          {/* Form */}
          <form onSubmit={isSignUp ? handleSignUp : handleLogin} className="w-full max-w-md space-y-5">
            {isSignUp && (
              <div>
                <label className="block text-sm font-medium text-[#4b5563]">
                  Full Name
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full px-4 py-2 border border-[#d1d5db] rounded-md focus:ring-2 focus:ring-[#22195b] focus:outline-none"
                />
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-[#4b5563]">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-2 border border-[#d1d5db] rounded-md focus:ring-2 focus:ring-[#22195b] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#4b5563]">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-2 border border-[#d1d5db] rounded-md focus:ring-2 focus:ring-[#22195b] focus:outline-none"
              />
            </div>
            {isSignUp && (
              <div>
                <label className="block text-sm font-medium text-[#4b5563]">
                  Confirm Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2 border border-[#d1d5db] rounded-md focus:ring-2 focus:ring-[#22195b] focus:outline-none"
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-themepurple text-white py-2 rounded-md hover:bg-[#352c84] transition-all duration-300"
            >
              {isSignUp ? "Create Account" : "Login"}
            </button>

            {/* Display error message if login fails */}
            {error && <div className="text-red-500 text-sm mt-2">{error}</div>}
          </form>

          {/* Switch Form Link */}
          <motion.div
            className="text-sm text-[#6b7280] mt-4 cursor-pointer hover:underline"
            whileHover={{ scale: 1.05 }}
            onClick={toggleForm}
          >
            {isSignUp
              ? "Already have an account? Login"
              : "Don't have an account? Sign Up"}
          </motion.div>

          {/* Show Logout Button when Logged In */}
          {isLoggedIn && (
            <button
              onClick={handleLogout}
              className="w-full bg-red-500 text-white py-2 rounded-md hover:bg-red-600 transition-all duration-300 mt-4"
            >
              Log Out
            </button>
          )}
        </div>
      </div>

      {/* Toast Container */}
      <ToastContainer />
    </div>
  );
};

export default AuthPage;
