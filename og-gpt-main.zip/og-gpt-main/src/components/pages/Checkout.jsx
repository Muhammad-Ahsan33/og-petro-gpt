import React, { useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const CheckoutPage = () => {
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const packages = [
    { id: 1, name: "Basic Package", price: "PKR 1000" },
    { id: 2, name: "Standard Package", price: "PKR 2500" },
    { id: 3, name: "Premium Package", price: "PKR 5000" },
  ];

  const handlePackageSelect = (pkg) => {
    setSelectedPackage(pkg);
  };

  const handleSignUp = (e) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Please fill in all fields.");
      return;
    }
    toast.success("Sign-up successful!");
    setError("");
  };

  const handlePayment = (method) => {
    toast.success(`Payment via ${method} successful!`);
    navigate("/thank-you"); // Redirect to a thank-you or success page
  };

  return (
    <div className="bg-gradient-to-r from-[#f8f0fb] to-[#f9fae4] min-h-screen flex items-center justify-center p-4">
      <div className="relative w-full max-w-5xl bg-[#ffffff] rounded-xl shadow-lg overflow-hidden flex">
        {/* Left Section */}
        <motion.div className="w-full md:w-1/2 flex flex-col justify-center items-center p-8 space-y-6">
          <h2 className="text-3xl font-bold text-themepurple">Checkout</h2>

          {/* Package Selection */}
          <div className="space-y-4 w-full">
            <h3 className="text-lg font-medium">Select a Package</h3>
            {packages.map((pkg) => (
              <div
                key={pkg.id}
                onClick={() => handlePackageSelect(pkg)}
                className={`cursor-pointer p-4 border border-gray-300 rounded-md ${
                  selectedPackage?.id === pkg.id
                    ? "bg-[#e0e0e0] border-themepurple"
                    : "hover:bg-[#f0f0f0]"
                }`}
              >
                <h4 className="font-semibold">{pkg.name}</h4>
                <p>{pkg.price}</p>
              </div>
            ))}
          </div>

          {/* Sign-up Form */}
          <form onSubmit={handleSignUp} className="w-full max-w-md space-y-4">
            <h3 className="text-lg font-medium">Sign Up</h3>
            <div>
              <label className="block text-sm font-medium text-[#4b5563]">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-2 border border-[#d1d5db] rounded-md focus:ring-2 focus:ring-[#22195b] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#4b5563]">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-2 border border-[#d1d5db] rounded-md focus:ring-2 focus:ring-[#22195b] focus:outline-none"
              />
            </div>

            {error && <div className="text-red-500 text-sm mt-2">{error}</div>}

            <button
              type="submit"
              className="w-full bg-themepurple text-white py-2 rounded-md hover:bg-[#352c84] transition-all duration-300"
            >
              Sign Up
            </button>
          </form>
        </motion.div>

        {/* Right Section (Payment Options) */}
        <div className="w-full md:w-1/2 flex flex-col justify-center items-center p-8 space-y-6 bg-[#ffffff]">
          <h2 className="text-2xl font-bold text-themepurple">
            Choose Payment Method
          </h2>

          {/* Payment Options */}
          <div className="w-full space-y-4">
            <button
              onClick={() => handlePayment("HBL")}
              className="w-full p-4 border border-[#d1d5db] rounded-md flex justify-between items-center hover:bg-[#f0f0f0] transition-all duration-300"
            >
              <img
                src="https://example.com/hbl-logo.png" // Replace with actual logo URL
                alt="HBL Logo"
                className="h-8"
              />
              <span className="text-lg font-semibold">
                HBL (Habib Bank Limited)
              </span>
            </button>
            <button
              onClick={() => handlePayment("UBL")}
              className="w-full p-4 border border-[#d1d5db] rounded-md flex justify-between items-center hover:bg-[#f0f0f0] transition-all duration-300"
            >
              <img
                src="https://example.com/ubl-logo.png" // Replace with actual logo URL
                alt="UBL Logo"
                className="h-8"
              />
              <span className="text-lg font-semibold">
                UBL (United Bank Limited)
              </span>
            </button>
            <button
              onClick={() => handlePayment("E-Wallet")}
              className="w-full p-4 border border-[#d1d5db] rounded-md flex justify-between items-center hover:bg-[#f0f0f0] transition-all duration-300"
            >
              <img
                src="https://example.com/wallet-logo.png" // Replace with actual wallet logo
                alt="Wallet Logo"
                className="h-8"
              />
              <span className="text-lg font-semibold">E-Wallet</span>
            </button>
          </div>
        </div>
      </div>

      {/* Toast Container */}
      <ToastContainer />
    </div>
  );
};

export default CheckoutPage;
