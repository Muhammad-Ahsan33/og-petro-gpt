import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import AuthPage from "./components/pages/auth/AuthPage";
import ProfilePage from "./components/pages/userProfile/ProfilePage";
import HomePage from "./components/pages/home/HomePage";
import ProtectedRoute from "./components/pages/ProtectedRoute"; 
import ChatPage from "./components/pages/chat/Chatpage";

const App = () => {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/auth" element={<AuthPage />} />
          {/* <Route path="/profile" element={<ProfilePage />} /> */}
          
          {/* Protect the chat route */}
          <Route
            path="/chat"
            element={
              <ProtectedRoute>
                <ChatPage />
              </ProtectedRoute>
            }
          />
        </Routes>
      </AuthProvider>
    </Router>
  );
};

export default App;
