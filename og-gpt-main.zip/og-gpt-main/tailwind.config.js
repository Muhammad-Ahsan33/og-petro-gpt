module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // Adjust paths based on your project structure
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Helvetica", "Arial", "sans-serif"],
      },
      colors: {
        softWhite: "#f4f4f4", // Soft white
        themepurple: "#6832C5", // Purple
        softBlack: "#20182e", // Soft black
      },
    },
  },
  plugins: [],
};
