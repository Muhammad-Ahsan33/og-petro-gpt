from fastapi import FastAPI, HTTPException, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from pymongo import MongoClient
from pydantic import BaseModel, EmailStr
from bson import ObjectId
from typing import Optional
from datetime import datetime
from urllib.parse import quote_plus
import os
from dotenv import load_dotenv
from passlib.context import CryptContext
import ollama

load_dotenv()

MODEL_MAP = {
    1: "Drilling",
    2: "Reservoir",
    3: "Manufacturing"
}

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # React frontend URL
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)


# MongoDB Connection
username = quote_plus(os.getenv("MONGODB_USERNAME"))
password = quote_plus(os.getenv("MONGODB_PASSWORD"))
cluster_url = os.getenv("MONGODB_CLUSTER_URL")

uri = f"mongodb+srv://{username}:{password}@{cluster_url}/?retryWrites=true&w=majority"
client = MongoClient(uri)
db = client.get_database("chatbot")

# Pydantic models
class UserCreate(BaseModel):
    fullName: str
    email: str
    password: str

class SignInRequest(BaseModel):
    email: EmailStr
    password: str

class ChatCreate(BaseModel):
    user_id: str
    title: str
    model_id: Optional[int] = 1  # Default 1 model (can change later)

class QueryCreate(BaseModel):
    chat_id: str
    user_message: str

class RenameChatRequest(BaseModel):
    chat_id: str
    new_title: str

class SuggestTitleRequest(BaseModel):
    chat_id: str
    query: str

# Password hash
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

# AI response
def generate_ai_response(chat_id: str, model_name: str) -> str:
    """
    Generates an AI response using the Ollama model, including chat history.
    """
    try:
        # Fetch the chat history from the database
        messages = list(
            db.messages.find({"chat_id": ObjectId(chat_id)})
            .sort("timestamp", 1)  # Ensure messages are in chronological order
        )

        # Format messages as required by Ollama
        ollama_messages = [
            {"role": "user" if msg["sender"] == "user" else "assistant", "content": msg["message"]}
            for msg in messages
        ]

        # Add the latest user input to the messages if necessary (done in /query)
        response = ollama.chat(
            model=model_name,
            messages=ollama_messages,
            stream=False  # No streaming in this case
        )

        # Extract and return AI response content
        return response.get("message", {}).get("content", "No response generated.")
    except Exception as e:
        # Handle errors gracefully
        print(f"Error generating AI response: {e}")
        return "Sorry, I encountered an issue generating a response."

# Sign up route
@app.post("/signup", response_model=dict)
async def sign_up(user: UserCreate):
    if db.users.find_one({"email": user.email}):
        raise HTTPException(status_code=400, detail="Email already exists")

    user_data = {
        "fullName": user.fullName,
        "email": user.email,
        "password_hash": hash_password(user.password),
        "subscription_type": None,  # default none, later set
        "created_at": datetime.utcnow()
    }
    result = db.users.insert_one(user_data)
    return {"message": "Sign-up successful", "user_id": str(result.inserted_id)}

# Sign in route
@app.post("/signin", response_model=dict)
async def sign_in(user: SignInRequest):
    user_data = db.users.find_one({"email": user.email})
    if not user_data or not pwd_context.verify(user.password, user_data["password_hash"]):
        raise HTTPException(status_code=400, detail="Invalid credentials")
    
    return {"message": "Sign-in successful", "user_id": str(user_data["_id"])}

# New chat route
@app.post("/newchat", response_model=dict)
async def create_chat(chat: ChatCreate):
    chat_data = {
        "user_id": ObjectId(chat.user_id),
        "title": chat.title,
        "model_id": chat.model_id,
        "created_at": datetime.utcnow(),
        "last_updated": datetime.utcnow()
    }
    result = db.chats.insert_one(chat_data)
    return {"message": "Chat created successfully", "chat_id": str(result.inserted_id)}

# Query route
@app.post("/query", response_model=dict)
async def submit_query(query: QueryCreate):
    chat_id = ObjectId(query.chat_id)

    # Save user message to the database
    user_message_data = {
        "chat_id": chat_id,
        "sender": "user",
        "message": query.user_message,
        "timestamp": datetime.utcnow()
    }
    db.messages.insert_one(user_message_data)

    # Retrieve the chat to determine the selected model
    chat_data = db.chats.find_one({"_id": chat_id})
    if not chat_data:
        raise HTTPException(status_code=404, detail="Chat not found.")

    model_id = chat_data.get("model_id", 1)  # Default to 1 if not set
    model_name = MODEL_MAP.get(model_id, "llama3.1:latest") # Default llama if custom not found

    # Generate AI response with chat history
    ai_response = generate_ai_response(str(chat_id), model_name)

    # Save AI response to the database
    ai_message_data = {
        "chat_id": chat_id,
        "sender": "ai",
        "message": ai_response,
        "timestamp": datetime.utcnow()
    }
    db.messages.insert_one(ai_message_data)

    return {"user_message": query.user_message, "ai_response": ai_response}


# Get chats for a user
@app.get("/chats", response_model=dict)
async def get_user_chats(user_id: str):
    chats = list(
        db.chats.find({"user_id": ObjectId(user_id)})
        .sort("last_updated", -1)
    )
    if not chats:
        return {"message": "No chats found", "chats": []}

    chats_data = [
        {
            "id": str(chat["_id"]),
            "title": chat["title"],
            "last_updated": chat["last_updated"]
        }
        for chat in chats
    ]
    return {"message": "Chats fetched successfully", "chats": chats_data}


# Get messages for a chat
@app.get("/messages", response_model=dict)
async def get_chat_messages(chat_id: str):
    messages = list(
        db.messages.find({"chat_id": ObjectId(chat_id)})
        .sort("timestamp", 1)
    )
    if not messages:
        return {"message": "No messages found", "messages": []}

    messages_data = [
        {
            "sender": message["sender"],
            "message": message["message"],
            "timestamp": message["timestamp"]
        }
        for message in messages
    ]
    return {"message": "Messages fetched successfully", "messages": messages_data}


# Rename chat route
@app.put("/renameChat", response_model=dict)
async def rename_chat(rename_request: RenameChatRequest):
    chat_id = ObjectId(rename_request.chat_id)
    new_title = rename_request.new_title.strip()

    if not new_title:
        raise HTTPException(status_code=400, detail="Title cannot be empty.")

    result = db.chats.update_one(
        {"_id": chat_id},
        {"$set": {"title": new_title, "last_updated": datetime.utcnow()}}
    )

    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Chat not found.")

    return {"message": "Chat renamed successfully", "chat_id": str(chat_id), "new_title": new_title}


# Delete chat route
@app.delete("/deleteChat/{chat_id}", response_model=dict)
async def delete_chat(chat_id: str):
    chat_object_id = ObjectId(chat_id)

    chat_result = db.chats.delete_one({"_id": chat_object_id})
    messages_result = db.messages.delete_many({"chat_id": chat_object_id})

    if chat_result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Chat not found.")

    return {
        "message": "Chat deleted successfully",
        "deleted_chat_id": chat_id,
        "deleted_messages_count": messages_result.deleted_count
    }

# Route to suggest title for new chat
@app.post("/suggestTitle", response_model=dict)
async def suggest_title(request: SuggestTitleRequest):
    query = request.query.strip()
    chat = db.chats.find_one({"_id": ObjectId(request.chat_id)})
    
    if (not chat) or (not query):
        return {"title": "Untitled Chat"}
    
    model_id = chat.get("model_id", 1)  # Default to 1 if not set
    model_name = MODEL_MAP.get(model_id, "llama3.1:latest") # Default llama if custom not found

    prompt = f"""Generate a concise and meaningful chat title that captures the purpose for the given user query. Try to use exact words from the query.
                Do not add quotation marks before and after the title. DO NOT USE MORE THAN 3 WORDS Here is the query:\n\n\"{query}\".\n\nTitle:"""
    
    response = ollama.chat(
        model=model_name,
        messages=[{"role": "user", "content": prompt}],
        stream=False
    )

    suggested_title = response.get("message", {}).get("content", "").strip()
    if not suggested_title:
        suggested_title = "Untitled Chat"

    return {"title": suggested_title}
